package com.nlappsstudio.translatorpro

import android.Manifest
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var isTtsInitialized by mutableStateOf(false)

    // Speech to text launcher
    private val speechRecognizerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val spokenText = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.get(0) ?: ""
            onVoiceInputReceived(spokenText)
        }
    }

    private var onVoiceInputReceived: (String) -> Unit = {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        setContent {
            MaterialTheme(
                colorScheme = if (true) darkColorScheme() else lightColorScheme()
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    TranslatorAppScreen(
                        isTtsReady = isTtsInitialized,
                        onSpeakText = { text, langCode -> speakOut(text, langCode) },
                        onLaunchSpeechToText = { callback ->
                            onVoiceInputReceived = callback
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak now to translate...")
                            }
                            speechRecognizerLauncher.launch(intent)
                        }
                    )
                }
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsInitialized = true
        }
    }

    private fun speakOut(text: String, langCode: String) {
        if (isTtsInitialized) {
            val locale = Locale(langCode)
            tts?.language = locale
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

data class HistoryItem(
    val id: String,
    val originalText: String,
    val translatedText: String,
    val sourceLang: String,
    val targetLang: String,
    val isFavorite: Boolean = false
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TranslatorAppScreen(
    isTtsReady: Boolean,
    onSpeakText: (String, String) -> Unit,
    onLaunchSpeechToText: ((String) -> Unit) -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    var sourceText by remember { mutableStateOf("") }
    var translatedText by remember { mutableStateOf("") }
    var sourceLang by remember { mutableStateOf("Auto Detect") }
    var targetLang by remember { mutableStateOf("Spanish") }
    var isTranslating by remember { mutableStateOf(false) }

    var selectedTab by remember { mutableIntStateOf(0) }
    var historyList by remember {
        mutableStateOf(
            listOf(
                HistoryItem("1", "Hello, how are you doing today?", "Hola, ¿cómo estás hoy?", "English", "Spanish", true),
                HistoryItem("2", "Good morning, welcome to Translator Pro", "Bonjour, bienvenue sur Translator Pro", "English", "French", false)
            )
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text("Translator Pro", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) 
                },
                actions = {
                    IconButton(onClick = { /* Dark Mode Toggle */ }) {
                        Icon(Icons.Default.DarkMode, contentDescription = "Theme")
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Translate, contentDescription = "Translate") },
                    label = { Text("Translate") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.History, contentDescription = "History") },
                    label = { Text("History") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Star, contentDescription = "Favorites") },
                    label = { Text("Favorites") }
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            if (selectedTab == 0) {
                // Main Translation View
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    // Language Selection Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(24.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { /* Source language list */ }
                                .padding(vertical = 12.dp, horizontal = 16.dp)
                        ) {
                            Text(sourceLang, textAlign = TextAlign.Center, fontWeight = FontWeight.Medium)
                        }
                        
                        IconButton(onClick = {
                            if (sourceLang != "Auto Detect") {
                                val temp = sourceLang
                                sourceLang = targetLang
                                targetLang = temp
                            }
                        }) {
                            Icon(Icons.Default.SwapHoriz, contentDescription = "Swap")
                        }

                        Surface(
                            shape = RoundedCornerShape(24.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { /* Target language list */ }
                                .padding(vertical = 12.dp, horizontal = 16.dp)
                        ) {
                            Text(targetLang, textAlign = TextAlign.Center, fontWeight = FontWeight.Medium)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Original Text Card
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            OutlinedTextField(
                                value = sourceText,
                                onValueChange = { sourceText = it },
                                placeholder = { Text("Enter text to translate...") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(
                                    unfocusedBorderColor = Color.Transparent,
                                    focusedBorderColor = Color.Transparent
                                )
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(onClick = {
                                    onLaunchSpeechToText { text ->
                                        sourceText = text
                                    }
                                }) {
                                    Icon(Icons.Default.Mic, contentDescription = "Voice Input")
                                }
                                IconButton(onClick = { /* Camera Scanner */ }) {
                                    Icon(Icons.Default.CameraAlt, contentDescription = "Camera Translate")
                                }
                                if (sourceText.isNotEmpty()) {
                                    IconButton(onClick = { sourceText = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear")
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Translate Button
                    Button(
                        onClick = {
                            if (sourceText.trim().isNotEmpty()) {
                                isTranslating = true
                                // Simulating high-fidelity local on-device ML translation
                                runLocalOnDeviceTranslation(
                                    sourceText, sourceLang, targetLang,
                                    onSuccess = { result ->
                                        translatedText = result
                                        isTranslating = false
                                        // Save to history
                                        historyList = listOf(
                                            HistoryItem(
                                                id = System.currentTimeMillis().toString(),
                                                originalText = sourceText,
                                                translatedText = result,
                                                sourceLang = sourceLang,
                                                targetLang = targetLang
                                            )
                                        ) + historyList
                                    }
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isTranslating) {
                            CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(24.dp))
                        } else {
                            Text("Translate", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Translation Result Card
                    if (translatedText.isNotEmpty()) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = translatedText,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxWidth(),
                                    fontSize = 18.sp
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    IconButton(onClick = {
                                        onSpeakText(translatedText, "es")
                                    }) {
                                        Icon(Icons.Default.VolumeUp, contentDescription = "TTS")
                                    }
                                    IconButton(onClick = {
                                        clipboardManager.setText(AnnotatedString(translatedText))
                                    }) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy")
                                    }
                                    IconButton(onClick = {
                                        val sendIntent: Intent = Intent().apply {
                                            action = Intent.ACTION_SEND
                                            putExtra(Intent.EXTRA_TEXT, translatedText)
                                            type = "text/plain"
                                        }
                                        context.startActivity(Intent.createChooser(sendIntent, null))
                                    }) {
                                        Icon(Icons.Default.Share, contentDescription = "Share")
                                    }
                                }
                            }
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Your translation will appear here", color = MaterialTheme.colorScheme.outline)
                        }
                    }
                }
            } else if (selectedTab == 1) {
                // History List
                LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                    item {
                        Text("Translation History", fontWeight = FontWeight.Bold, fontSize = 20.sp, modifier = Modifier.padding(bottom = 16.dp))
                    }
                    items(historyList) { item ->
                        HistoryCard(item)
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            } else {
                // Favorites List
                val favorites = historyList.filter { it.isFavorite }
                LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                    item {
                        Text("Favorite Translations", fontWeight = FontWeight.Bold, fontSize = 20.sp, modifier = Modifier.padding(bottom = 16.dp))
                    }
                    if (favorites.isEmpty()) {
                        item {
                            Box(modifier = Modifier.fillParentMaxSize(), contentAlignment = Alignment.Center) {
                                Text("No favorites saved yet", color = MaterialTheme.colorScheme.outline)
                            }
                        }
                    } else {
                        items(favorites) { item ->
                            HistoryCard(item)
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryCard(item: HistoryItem) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${item.sourceLang} ➔ ${item.targetLang}", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Icon(
                    imageVector = if (item.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                    contentDescription = "Favorite",
                    tint = if (item.isFavorite) Color(0xFFFFB300) else MaterialTheme.colorScheme.outline
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(item.originalText, fontWeight = FontWeight.Medium, fontSize = 15.sp)
            Spacer(modifier = Modifier.height(4.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(4.dp))
            Text(item.translatedText, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        }
    }
}

// Simulates the on-device translation powered by Google ML Kit
fun runLocalOnDeviceTranslation(
    text: String,
    source: String,
    target: String,
    onSuccess: (String) -> Unit
) {
    // Under the hood, Google ML Kit initiates translation in 3 steps:
    // 1. Language Identification model identifies source language if Auto Detect.
    // 2. Download specific translation models over WiFi (completely free!).
    // 3. Translates offline with high accuracy and low-latency.
    
    // Simulating translation outcome immediately for responsiveness
    val mockTranslation = when (target) {
        "Spanish" -> "Hola, esta es una traducción de Translator Pro."
        "French" -> "Bonjour, c'est une traduction de Translator Pro."
        "German" -> "Hallo, dies ist eine Übersetzung von Translator Pro."
        "Chinese" -> "您好，这是 Translator Pro 的翻译。"
        "Japanese" -> "こんにちは、これは Translator Pro の翻訳です。"
        else -> "Translation of: "$text" to $target"
    }
    
    android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
        onSuccess(if (text.length < 15) mockTranslation else "Translated: $text (to $target)")
    }, 500)
}
